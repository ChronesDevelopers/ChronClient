﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Chrones
{
    public static partial class Cmr
    {
        public static partial class Math
        {
            public static Vector3 WorldToScreen(Vector3 position)
            {
                throw new NotImplementedException();
            }
        }
    }
}
