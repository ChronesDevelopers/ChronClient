﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronClient.Data
{
    public static partial class GlobalData
    {
        public static partial class MainWindow
        {
            public static GUI.MainWindow Window;
            public static IntPtr WindowHandle;
        }
    }
}
