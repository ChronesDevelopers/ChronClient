﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronClient.File
{
    public class ProfileClassSettingsCollection
    {
        public string Name { get; set; }
        public ProfileClassSetting[] Settings { get; set; }
    }
}
