﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronClient.memory.Modules.Module
{
    class WeirdMode
    {
        //Minecraft.Windows.exe+2403B5C
    }
}
